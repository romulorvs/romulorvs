import React, { useState, useEffect, useRef } from "react";
import "./admin-page.css";
import UserSelector from "./UserSelector";
import OnOffButton from "./OnOffButton";
import { getUsersData, setUserDB } from "./utils";
import TermContainer from "./TermContainer";

function App() {
  const userUlRef = useRef(null);
  const userUlTimer = useRef(null);
  const noUsersFound = useRef(false);
  const [loadingState, setLoadingState] = useState(false);
  const [reRender, setReRender] = useState(false);
  const [currentUser, setCurrentUser] = useState({});
  const [allUsers, setAllUsers] = useState([]);

  const usersData = useRef({
    quant: 200,
    offset: 0,
    totalUsers: 0,
    search: "",
  });

  const newUsersDataHandler = (newUsersData) => {
    if (newUsersData.data.length > 0) {
      usersData.current.totalUsers = newUsersData.totalUsers;

      setAllUsers([
        ...allUsers,
        ...newUsersData.data.map((user) => ({
          userId: parseInt(user.userId),
          userName: user.userName,
          isActive: user.isActive === "1",
        })),
      ]);
    } else {
      noUsersFound.current = true;
      setReRender(!reRender);
    }
  };

  useEffect(() => {
    if (allUsers.length > 0) {
      usersData.current.offset = allUsers.length;
      setLoadingState(false);
    }
  }, [allUsers]);

  useEffect(() => {
    if (!loadingState && userUlTimer.current === null) {
      userUlTimer.current = setInterval(() => {
        const scrollPos =
          (userUlRef.current.clientHeight + userUlRef.current.scrollTop) /
          userUlRef.current.scrollHeight;

        if (scrollPos > 0.8) {
          clearInterval(userUlTimer.current);
          userUlTimer.current = null;
          setLoadingState(true);
          getUsersData(usersData.current.quant, usersData.current.offset, newUsersDataHandler);
        }
      }, 100);
    }
  }, [loadingState]);

  const changeCurrentUser = (newCurrentUser) => {
    if (typeof currentUser.userId === "undefined") {
      setCurrentUser(newCurrentUser);
    } else {
      if (newCurrentUser.userId !== currentUser.userId) {
        setCurrentUser(newCurrentUser);
      } else if (newCurrentUser.isActive !== currentUser.isActive) {
        const newUsers = allUsers.slice();

        if (
          typeof newCurrentUser.arrKey !== "undefined" &&
          newUsers[newCurrentUser.arrKey].userId === newCurrentUser.userId
        ) {
          newUsers[newCurrentUser.arrKey].isActive = newCurrentUser.isActive;
          setAllUsers(newUsers);
        } else {
          setAllUsers(
            allUsers.map((user) => {
              if (user.userId === newCurrentUser.userId) {
                return { ...user, isActive: newCurrentUser.isActive };
              } else {
                return user;
              }
            })
          );
        }

        setUserDB(newCurrentUser.userId, newCurrentUser.isActive);
        setCurrentUser(newCurrentUser);
      }
    }
  };

  return (
    <>
      <div id="resautcat-content-user" className="resautcat-type-container">
        <div
          id="resautcat-user-title-container"
          className={["resautcat-title-container", currentUser.userId ? "selected-user" : ""].join(
            " "
          )}
        >
          <h3 id="resautcat-user-title" className="resautcat-type-title">
            {currentUser.userName || "Users"}
          </h3>

          {!!currentUser.userId && (
            <OnOffButton
              title="Activate/Deactivate User"
              selected={!!currentUser.isActive}
              onClick={() =>
                changeCurrentUser({
                  ...currentUser,
                  isActive: !currentUser.isActive,
                })
              }
            />
          )}
        </div>

        <ul id="resautcat-user-ul" className="resautcat-type-ul" ref={userUlRef}>
          {allUsers.map((user, arrKey) => (
            <UserSelector
              key={user.userId}
              changeCurrentUser={changeCurrentUser}
              arrKey={arrKey}
              userData={user}
              isSelected={currentUser.userId === user.userId}
            />
          ))}

          {!noUsersFound.current &&
            allUsers.length > 0 &&
            allUsers.length < usersData.current.totalUsers && (
              <li className="resautcat-user-li resautcat-type-li resautcat-loading-li">
                <button>Loading Users</button>
                <div className="lds-dual-ring" />
              </li>
            )}

          {!noUsersFound.current && allUsers.length === 0 && (
            <div className="resautcat-message">
              <div className="lds-dual-ring" />
            </div>
          )}

          {noUsersFound.current && allUsers.length === 0 && (
            <div className="resautcat-message">
              <h3>No User Found</h3>
              <p>You can only select non-admin users</p>
            </div>
          )}
        </ul>
      </div>

      <div id="resautcat-content-term" className="resautcat-type-container">
        <TermContainer
          changeCurrentUser={changeCurrentUser}
          currentUser={currentUser}
          currentUserId={currentUser.userId}
          parent={0}
          isPrimary={true}
          chainChangeCanEditPost={[]}
          prevTermCanEditPost={null}
          parentSetHideChildren={null}
          usersLength={allUsers.length}
        />
      </div>
    </>
  );
}

export default App;
