import "react-app-polyfill/ie11";
import "react-app-polyfill/stable";
import React from "react";
import ReactDOM from "react-dom";
import App from "./App";

window.addEventListener("load", () => {
  ReactDOM.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
    document.getElementById("resautcat-content-container")
  );

  document.querySelector("#resautcat-page-admin").style.opacity = 1;
});
