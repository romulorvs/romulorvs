import React, { useEffect, useState, useRef } from "react";
import { minusSvg, plusSvg } from "./svgIcons";
import TermContainer from "./TermContainer";
import { setTermDB } from "./utils";

function TermSelector(props) {
  const [termCanEditPost, setTermCanEditPost] = useState(props.termData.termCanEditPost);
  const [loadChildren, setLoadChildren] = useState(false);
  const [hideChildren, setHideChildren] = useState(true);
  const [childrenDataIsLoaded, setChildrenDataIsLoaded] = useState(false);
  const unhideParent = useRef(false);

  const changeCanEditPost = (newTermCanEditPost) => {
    if (newTermCanEditPost !== termCanEditPost) {
      setTermCanEditPost(newTermCanEditPost);
      setTermDB(props.termData.termId, props.currentUser.userId, newTermCanEditPost);
    }

    if (newTermCanEditPost) {
      props.changeCurrentUser({
        ...props.currentUser,
        isActive: newTermCanEditPost,
      });
    }
  };

  const buttonClickHandler = () => {
    const newTermCanEditPost = !termCanEditPost;

    if (newTermCanEditPost) {
      props.chainChangeCanEditPost.forEach((f) => f(newTermCanEditPost));
    }

    changeCanEditPost(newTermCanEditPost);
  };

  useEffect(() => {
    if (props.prevTermCanEditPost === false) {
      changeCanEditPost(false);
    }
  }, [props.prevTermCanEditPost]);

  useEffect(() => {
    if (props.termData.termChildren > 0 && props.termData.termCanEditPost) {
      setLoadChildren(true);
      unhideParent.current = true;
    }

    if (props.termData.termCanEditPost && props.parentSetHideChildren !== null) {
      props.parentSetHideChildren();
    }
  }, []);

  const expandChildren = () => {
    if (loadChildren === false) {
      setLoadChildren(true);
      setHideChildren(false);
    } else {
      setHideChildren(!hideChildren);
    }
  };

  return (
    <li
      className={[
        "resautcat-term-li resautcat-type-li",
        termCanEditPost ? "active" : "",
        childrenDataIsLoaded && !hideChildren ? "expanded" : "",
      ].join(" ")}
    >
      <div className="resautcat-term-li-container">
        <button
          className="resautcat-term-name resautcat-type-button-container"
          onClick={buttonClickHandler}
        >
          <div
            className={[
              "resautcat-term-button resautcat-type-button",
              termCanEditPost ? "selected" : "",
            ].join(" ")}
          />

          {props.termData.termName}
        </button>

        {props.termData.termChildren > 0 && (
          <>
            <button
              className="resautcat-term-expand-button"
              onClick={expandChildren}
              title="Expand Sub-Categories"
              disabled={loadChildren && !childrenDataIsLoaded ? "disabled" : undefined}
            >
              <div className={"resautcat-term-expand-svg-container"}>
                {loadChildren && !childrenDataIsLoaded ? (
                  <div className="lds-dual-ring" />
                ) : childrenDataIsLoaded && !hideChildren ? (
                  minusSvg
                ) : (
                  plusSvg
                )}
              </div>
            </button>
          </>
        )}
      </div>

      {loadChildren && (
        <TermContainer
          changeCurrentUser={props.changeCurrentUser}
          currentUser={props.currentUser}
          currentUserId={props.currentUserId}
          parent={props.termData.termId}
          setChildrenDataIsLoaded={setChildrenDataIsLoaded}
          chainChangeCanEditPost={[...props.chainChangeCanEditPost, changeCanEditPost]}
          prevTermCanEditPost={termCanEditPost}
          hideContainer={hideChildren}
          parentSetHideChildren={unhideParent.current ? setHideChildren : null}
        />
      )}
    </li>
  );
}

export default TermSelector;
