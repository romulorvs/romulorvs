import React, { useState, useEffect, useRef } from "react";
import { getTermsData, getTermsDataPrimary } from "./utils";
import TermSelector from "./TermSelector";
import { plusSvg } from "./svgIcons";

function TermContainer(props) {
  const hasLoadedUser = useRef(!props.isPrimary);
  const termUlRef = useRef(null);
  const termUlTimer = useRef(null);
  const noTermsFound = useRef(false);
  const firstRun = useRef(true);
  const allGetTerms = useRef([]);
  const allGetTermsTracker = useRef(0);
  const hasChangedUser = useRef(null);
  const [loadingState, setLoadingState] = useState(!!props.isPrimary);
  const [reRender, setReRender] = useState(false);
  const [reRenderLoading, setReRenderLoading] = useState(false);
  const [allTerms, setAllTerms] = useState([]);

  const termsData = useRef({
    quant: props.isPrimary ? 200 : 10,
    userId: 0,
    parent: props.parent,
    offset: 0,
    search: "",
    totalTerms: 0,
  });

  const newTermsDataHandler = (newTermsData) => {
    if (newTermsData.data.length > 0) {
      termsData.current.totalTerms = parseInt(newTermsData.totalTerms);

      setAllTerms(
        allTerms.slice(0, parseInt(newTermsData.offset)).concat(
          newTermsData.data.map((term) => ({
            termId: parseInt(term.termId),
            termName: term.termName,
            termParent: parseInt(term.termParent),
            termCanEditPost: term.termCanEditPost === "1",
            termCanSeePost: term.termCanSeePost === "1",
            termChildren: parseInt(term.termChildren),
          }))
        )
      );
    } else {
      noTermsFound.current = true;
      setReRender(!reRender);
      setLoadingState(true);
    }
  };

  const getTermsDataHandler = () => {
    const funcIndex = allGetTerms.current.length;
    allGetTerms.current = [...allGetTerms.current, newTermsDataHandler];

    const getTermsParams = {
      userId: termsData.current.userId,
      quant: termsData.current.quant,
      offset: termsData.current.offset,
      parent: termsData.current.parent,
      search: termsData.current.search,
      callback: (response) => {
        if (
          typeof allGetTerms.current[funcIndex] !== "undefined" &&
          allGetTerms.current[funcIndex] !== null
        ) {
          allGetTerms.current[funcIndex](response);
        }
      },
    };

    if (props.isPrimary) {
      getTermsDataPrimary(getTermsParams);
    } else {
      getTermsData(getTermsParams);
    }
  };

  useEffect(() => {
    if (!props.isPrimary) {
      if (
        typeof allTerms[0] !== "undefined" &&
        typeof props.setChildrenDataIsLoaded !== "undefined"
      ) {
        props.setChildrenDataIsLoaded(true);
      }

      if (firstRun.current) {
        termsData.current.userId = props.currentUserId;
        firstRun.current = false;
        setLoadingState(true);
        getTermsDataHandler();
      }
    }

    if (allTerms.length > 0) {
      termsData.current.offset = allTerms.length;
      setLoadingState(false);
    }
  }, [allTerms]);

  useEffect(() => {
    if (props.isPrimary && !loadingState && termUlTimer.current === null) {
      termUlTimer.current = setInterval(() => {
        const scrollPos =
          (termUlRef.current.clientHeight + termUlRef.current.scrollTop) /
          termUlRef.current.scrollHeight;

        if (scrollPos > 0.8) {
          clearInterval(termUlTimer.current);
          termUlTimer.current = null;
          setLoadingState(true);
          getTermsDataHandler();
        }
      }, 100);
    }
  }, [loadingState, reRenderLoading]);

  useEffect(() => {
    if (hasChangedUser.current === null) {
      hasChangedUser.current = false;
    } else {
      termsData.current.userId = props.currentUserId;

      if (!props.isPrimary) {
        allGetTerms.current = [];
      } else {
        if (hasLoadedUser.current) {
          const trackerIndex =
            allGetTermsTracker.current - 1 <= 0 ? 0 : allGetTermsTracker.current - 1;

          for (let index = trackerIndex; index < allGetTerms.current.length; index++) {
            allGetTerms.current[index] = null;
          }

          allGetTermsTracker.current = allGetTerms.current.length - 1;

          if (termUlTimer.current !== null) {
            clearInterval(termUlTimer.current);
          }

          termUlTimer.current = null;
          noTermsFound.current = false;
          termsData.current.totalTerms = 0;
          termsData.current.offset = 0;
          setAllTerms([]);

          if (loadingState) {
            setLoadingState(false);
          } else {
            setReRenderLoading(!reRenderLoading);
          }
        } else {
          hasLoadedUser.current = true;
          setLoadingState(false);
        }
      }
    }
  }, [props.currentUserId]);

  return (
    <ul
      id={props.isPrimary ? "resautcat-term-ul" : ""}
      ref={termUlRef}
      className={["resautcat-type-ul", props.hideContainer ? "hide-ul" : ""].join(" ")}
    >
      {allTerms.map((term) => (
        <TermSelector
          key={term.termId}
          currentUser={props.currentUser}
          changeCurrentUser={props.changeCurrentUser}
          termData={term}
          chainChangeCanEditPost={props.chainChangeCanEditPost}
          prevTermCanEditPost={props.prevTermCanEditPost}
          parentSetHideChildren={props.parentSetHideChildren}
          currentUserId={props.currentUserId}
        />
      ))}

      {props.isPrimary &&
        allTerms.length > 0 &&
        allTerms.length < termsData.current.totalTerms &&
        hasLoadedUser.current && (
          <li className="resautcat-term-li resautcat-type-li resautcat-loading-li">
            <button>Loading Categories</button>
            <div className="lds-dual-ring" />
          </li>
        )}

      {props.isPrimary &&
        allTerms.length === 0 &&
        noTermsFound.current &&
        hasLoadedUser.current && (
          <div className="resautcat-message">
            <h3>No Category Found</h3>
          </div>
        )}

      {props.isPrimary &&
        allTerms.length === 0 &&
        hasLoadedUser.current &&
        !noTermsFound.current && (
          <div className="resautcat-message">
            <div className="lds-dual-ring" />
          </div>
        )}

      {props.isPrimary && props.usersLength > 0 && !hasLoadedUser.current && (
        <div className="resautcat-message">
          <h3>Select a User</h3>
        </div>
      )}

      {!props.isPrimary &&
        allTerms.length < termsData.current.totalTerms &&
        hasLoadedUser.current && (
          <li className="resautcat-term-li resautcat-type-li resautcat-load-more-terms-li">
            {loadingState ? (
              <div className="lds-dual-ring" />
            ) : (
              <button
                onClick={() => {
                  setLoadingState(true);
                  getTermsDataHandler();
                }}
              >
                {plusSvg}
                <span>Load More</span>
              </button>
            )}
          </li>
        )}
    </ul>
  );
}

export default TermContainer;
