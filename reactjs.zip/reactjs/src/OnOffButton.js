import React from "react";

function OnOffButton(props) {
  return (
    <button
      className={["resautcat-on-off-button", props.selected ? "selected" : ""].join(" ")}
      onClick={(e) => props.onClick(e)}
      title={props.title || undefined}
    >
      <div className="resautcat-on-off-button-back" />
      <div className="resautcat-on-off-button-round" />
    </button>
  );
}

export default OnOffButton;
