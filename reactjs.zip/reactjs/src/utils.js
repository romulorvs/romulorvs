const WP_LOCALHOST_DOMAIN = process.env.NODE_ENV === "development" ? "http://localhost:3000" : "";

export const resautcatAjax = (function () {
  const noop = function () {};

  const get = function (url, params, callback) {
    callback = "function" === typeof callback ? callback : noop;
    ajax("GET", url, params, callback);
  };

  const post = function (url, params, callback) {
    callback = "function" === typeof callback ? callback : noop;
    ajax("POST", url, params, callback);
  };

  const ajax = function (method, url, params, callback) {
    const xhr = new XMLHttpRequest(),
      target = url,
      args = params,
      validMethods = ["GET", "POST"];

    method = -1 !== validMethods.indexOf(method) ? method : "GET";
    xhr.open(method, target + ("GET" === method ? "?" + args : ""), true);

    if ("POST" === method) {
      xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    }

    xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");

    xhr.onreadystatechange = function () {
      if (
        4 === xhr.readyState &&
        200 <= xhr.status &&
        300 > xhr.status &&
        "function" === typeof callback
      ) {
        callback.call(undefined, JSON.parse(xhr.response));
      }
    };

    xhr.send("POST" === method ? args : null);
  };

  return { get, post };
})();

export const getUsersData = (quant, offset, callback) => {
  const url = `${WP_LOCALHOST_DOMAIN}/wp-json/resautcat_api_admin/users/${quant}/${offset}`;
  const params = "search=";

  resautcatAjax.get(url, params, function (response) {
    if (typeof response === "object" && response.result === "success") {
      callback(response);
    } else {
      console.log("Error on GET users on DB");
    }
  });
};

export const setUserDB = (userId, isActive) => {
  setUserDBHandler(null, userId, isActive);
};

export const waitingResponseUsers = {};
const modifiedIsActive = {};

const setUserUrl = (userId, isActive) => {
  return `${WP_LOCALHOST_DOMAIN}/wp-json/resautcat_api_admin/set_user/${userId}/${isActive}/`;
};

const setUserDBHandler = (response, userId, isActive) => {
  if (response !== null) {
    delete waitingResponseUsers[userId];

    if (response.result === "success") {
      const dbIsActive = response.data["isActive"] === "true";
      const dbUserId = parseInt(response.data["userId"]);

      if (
        (!dbIsActive && !!modifiedIsActive[dbUserId]) ||
        (dbIsActive && !modifiedIsActive[dbUserId])
      ) {
        resautcatAjax.get(setUserUrl(dbUserId, modifiedIsActive[dbUserId]), "", setUserDBHandler);
        delete waitingResponseUsers[dbUserId];
        return;
      }

      delete waitingResponseUsers[dbUserId];
      return;
    }
    return;
  }

  if (waitingResponseUsers[userId]) {
    modifiedIsActive[userId] = isActive;
    return;
  }

  resautcatAjax.get(setUserUrl(userId, isActive), "", setUserDBHandler);
  waitingResponseUsers[userId] = true;
  modifiedIsActive[userId] = isActive;
};

export const setTermDB = (termId, userId, canEditPost) => {
  setTermDBHandler(null, termId, userId, canEditPost);
};

export const waitingResponseTerms = {};
const modifiedCanEditPost = {};

function set_term_url(termId, currentUserId, canEditPost) {
  return `${WP_LOCALHOST_DOMAIN}/wp-json/resautcat_api_admin/set_term/${termId}/${currentUserId}/${canEditPost}/`;
}

function setTermDBHandler(response, tid, cuid, canEditPost) {
  if (response !== null) {
    delete waitingResponseTerms[`u${cuid}t${tid}`];

    if (response.result === "success") {
      const dbCuid = parseInt(response.data["userid"]);
      const dbTid = parseInt(response.data["termid"]);
      const dbCanEditPost = response.data["caneditpost"] === "true";
      const setTermUid = `u${dbCuid}t${dbTid}`;

      if (
        (!dbCanEditPost && !!modifiedCanEditPost[setTermUid]) ||
        (dbCanEditPost && !modifiedCanEditPost[setTermUid])
      ) {
        resautcatAjax.get(
          set_term_url(dbTid, dbCuid, modifiedCanEditPost[setTermUid]),
          "",
          setTermDBHandler
        );
        delete waitingResponseTerms[setTermUid];
        return;
      }

      delete waitingResponseTerms[setTermUid];
      return;
    }
    return;
  }

  const setTermUid = `u${cuid}t${tid}`;

  if (waitingResponseTerms[setTermUid]) {
    modifiedCanEditPost[setTermUid] = canEditPost;
    return;
  }

  resautcatAjax.get(set_term_url(tid, cuid, canEditPost), "", setTermDBHandler);
  waitingResponseTerms[setTermUid] = true;
  modifiedCanEditPost[setTermUid] = canEditPost;
}

let currentUserId = null;

const getCategoriesUrl = (userId, quant, offset, parent) => {
  return `${WP_LOCALHOST_DOMAIN}/wp-json/resautcat_api_admin/categories/${userId}/${quant}/${offset}/${parent}`;
};

export const getTermsData = (queryData) => {
  currentUserId = queryData.userId;

  const url = getCategoriesUrl(
    queryData.userId,
    queryData.quant,
    queryData.offset,
    queryData.parent
  );

  const params = "search=" + queryData.search;

  resautcatAjax.get(url, params, function (response) {
    if (typeof response === "object" && response.result === "success") {
      if (currentUserId === parseInt(response.userId)) {
        queryData.callback(response);
      }
    } else {
      console.log("Error on GET terms on DB");
    }
  });
};

let primaryCallback = null;
let primaryQueryData = {};
let waitingPrimaryResponse = false;

export const getTermsDataPrimary = (queryData) => {
  primaryQueryData = queryData;
  currentUserId = primaryQueryData.userId;
  primaryCallback = primaryQueryData.callback;
  getCategoriesDBHandler(null, primaryQueryData);
};

const getCategoriesDBHandler = (response, queryData) => {
  if (response !== null) {
    waitingPrimaryResponse = false;

    if (typeof response === "object" && response.result === "success") {
      if (
        typeof response.userId === "undefined" ||
        isNaN(parseInt(response.userId)) ||
        parseInt(response.userId) <= 0 ||
        typeof currentUserId === "undefined" ||
        isNaN(parseInt(currentUserId)) ||
        parseInt(currentUserId) <= 0
      ) {
        console.log("Error on GET terms on DB");
        return;
      }

      if (currentUserId === parseInt(response.userId)) {
        primaryCallback(response);
        return;
      } else {
        resautcatAjax.get(
          getCategoriesUrl(
            primaryQueryData.userId,
            primaryQueryData.quant,
            primaryQueryData.offset,
            primaryQueryData.parent
          ),
          "search=" + primaryQueryData.search,
          getCategoriesDBHandler
        );
        return;
      }
    }

    console.log("Error on GET terms on DB");
    return;
  }

  if (waitingPrimaryResponse) {
    return;
  }

  resautcatAjax.get(
    getCategoriesUrl(queryData.userId, queryData.quant, queryData.offset, queryData.parent),
    "search=" + queryData.search,
    getCategoriesDBHandler
  );

  waitingPrimaryResponse = true;
};
